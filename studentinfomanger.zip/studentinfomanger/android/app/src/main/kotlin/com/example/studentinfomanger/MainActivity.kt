package com.example.studentinfomanger

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
